/**
 * Stub declaration of NSObject.  Lots of things in the runtime require the 
 */
@interface NSObject
-retain;
-copy;
-(void)release;
-autorelease;
-(void)dealloc;
@end
