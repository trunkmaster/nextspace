/* All Rights reserved */

#include <AppKit/AppKit.h>

@interface MyController : NSObject
{
  id value;
}
- (void) buttonPressed: (id)sender;
@end
