/* All Rights reserved */

#include <AppKit/AppKit.h>
#include <InterfaceBuilder/IBInspector.h>

@interface GormNSSplitViewInspector : IBInspector
{
  id orientation;
}
@end
