/* All Rights reserved */

#include <AppKit/AppKit.h>
#include <InterfaceBuilder/InterfaceBuilder.h>

@interface GormHelpInspector : IBInspector
{
  id toolTip;
}
@end
