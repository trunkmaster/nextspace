#ifndef __NSFileVersion_h_GNUSTEP_BASE_INCLUDE
#define __NSFileVersion_h_GNUSTEP_BASE_INCLUDE

#import <Foundation/NSObject.h>

#if OS_API_VERSION(MAC_OS_X_VERSION_10_7,GS_API_LATEST)

@interface NSFileVersion : NSObject
@end

#endif
#endif
