@interface TestClass
+ (int) test;
@end
